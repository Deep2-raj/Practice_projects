package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Registration {

    public static void main(String[] args) throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        // Display the welcome page
        displayWelcomePage(driver);

        // Pause for 2 seconds (2000 milliseconds) to manually complete the registration (for demonstration purposes)
        Thread.sleep(2000);

        // Print the "Register Success" message
        System.out.println("Register Success");

        // Pause for 2 seconds (2000 milliseconds) before displaying the registration page
        Thread.sleep(2000);

        // Registration Automation
        registerNewEmployee(driver, "Deepak", "Deepak@gmail.com", "password123");

        // Close the browser
        driver.quit();
    }

    private static void displayWelcomePage(WebDriver driver) {
        String welcomePath = Registration.class.getResource("/welcome.html").toString();
        driver.get(welcomePath);
    }

    private static void registerNewEmployee(WebDriver driver, String name, String email, String password) throws InterruptedException {
        String registrationPath = Registration.class.getResource("/registration.html").toString();
        driver.get(registrationPath);

        // Fill out the registration form
        WebElement nameInput = driver.findElement(By.id("name"));
        WebElement emailInput = driver.findElement(By.id("email"));
        WebElement passwordInput = driver.findElement(By.id("password"));
        WebElement registerButton = driver.findElement(By.id("register-button"));

        nameInput.sendKeys(name);
        emailInput.sendKeys(email);
        passwordInput.sendKeys(password);
        Thread.sleep(2000);

        // Click the registration button
        registerButton.click();

        // Check if the window is still open
        if (!driver.getWindowHandles().isEmpty()) {
            // Wait for the success message
            try {
                WebElement successMessage = driver.findElement(By.xpath("//h1[contains(text(), 'Register Success')]"));
                if (successMessage.isDisplayed()) {
                    System.out.println("Register Success");
                }
            } catch (org.openqa.selenium.NoSuchElementException e) {
                System.out.println("Registerion page closed");
            }
        } else {
            System.out.println("Register Failed: Window closed");
        }
    }
}
