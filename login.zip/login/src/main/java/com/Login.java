package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Login {

    public static void main(String[] args) throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        // Navigate to the login page
        String path = "login.html";
        String url = Login.class.getClassLoader().getResource(path).toString();
        driver.get(url);
       

        // Login Automation
        login(driver, "Deepak@gmail.com", "password123");

        // Pause for 5 seconds (5000 milliseconds) before closing the browser
      
        Thread.sleep(1000);
        // Close the browser
        driver.quit();
    }

    private static void login(WebDriver driver, String email, String password) throws InterruptedException {
        WebElement emailInput = driver.findElement(By.id("login-email"));
        WebElement passwordInput = driver.findElement(By.id("login-password"));
        WebElement submitButton = driver.findElement(By.xpath("//button[text()='Submit']"));
       
        // Fill out the login form
        emailInput.sendKeys(email);
        passwordInput.sendKeys(password);
        Thread.sleep(2000);

        // Click the submit button
        submitButton.click();
        Thread.sleep(1000);
    
        System.out.println("Login Success");
    
       
        
    }
}
