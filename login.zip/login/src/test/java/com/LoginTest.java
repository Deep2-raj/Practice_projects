package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTest {

    private WebDriver driver;

    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        String path = LoginTest.class.getClassLoader().getResource("login.html").getPath();
        driver.get("file://" + path);
    }

    @Test
    public void testLogin() throws InterruptedException {
        loginEmployee(driver, "deepak@gmail.com", "password123");
        // Optionally, add assertions to verify login success or check for error messages
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }

    private void loginEmployee(WebDriver driver, String email, String password) throws InterruptedException {

        WebElement emailInput = driver.findElement(By.name("email"));
        WebElement passwordInput = driver.findElement(By.name("password"));
        WebElement submitButton = driver.findElement(By.xpath("//button[text()='Submit']"));

        // Fill out the login form
        emailInput.sendKeys(email);
        passwordInput.sendKeys(password);
Thread.sleep(2000);
        // Click the "Submit" button
        submitButton.click();

        // Optionally, add code to handle login success or failure scenarios
    }
}
