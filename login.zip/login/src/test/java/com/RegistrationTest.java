package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class RegistrationTest {

    private WebDriver driver;

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, java.util.concurrent.TimeUnit.SECONDS);
    }

    @Test(priority = 1)
    public void testWelcomePage() {
        // Test displaying the welcome page
        displayWelcomePage();
        // Pause for 5 seconds (5000 milliseconds) to manually interact with the page (for demonstration purposes)
        sleep(5000);
        // Print the "Welcome Page Test Successful" message
        System.out.println("Welcome Page Test Successful");
    }

    @Test(priority = 2)
    public void testRegistrationProcess() throws InterruptedException {
        // Test the registration process
        displayRegistrationPage();
        // Fill out the registration form
        registerNewEmployee("John Doe", "johndoe@example.com", "password123");
        // Pause for 5 seconds (5000 milliseconds) before checking for the "Register Success" message
        sleep(5000);
        // Check for the "Register Success" message
        boolean successMessageDisplayed = isElementDisplayed(By.xpath("//h1[contains(text(), 'Register Success')]"));

        if (successMessageDisplayed) {
            System.out.println("Register Success");
        }
    }

    @AfterClass
    public void teardown() {
        // Close the browser after the test is executed
        if (driver != null) {
            driver.quit();
        }
    }

    private void displayWelcomePage() {
        String welcomePath = RegistrationTest.class.getResource("/welcome.html").toString();
        driver.get(welcomePath);
    }

    private void displayRegistrationPage() {
        String registrationPath = RegistrationTest.class.getResource("/registration.html").toString();
        driver.get(registrationPath);
    }

    private void registerNewEmployee(String name, String email, String password) throws InterruptedException {
        WebElement nameInput = driver.findElement(By.id("name"));
        WebElement emailInput = driver.findElement(By.id("email"));
        WebElement passwordInput = driver.findElement(By.id("password"));
        WebElement registerButton = driver.findElement(By.id("register-button"));

        nameInput.sendKeys(name);
        emailInput.sendKeys(email);
        passwordInput.sendKeys(password);
        Thread.sleep(2000);
        // Click the registration button
        registerButton.click();
    }

    private boolean isElementDisplayed(By locator) {
        try {
            return driver.findElement(locator).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    private void sleep(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
